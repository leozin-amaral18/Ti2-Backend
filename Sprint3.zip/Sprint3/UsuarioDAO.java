package sprint3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO extends DAO {

    public UsuarioDAO() {
        super();
        conectar();
    }

    @Override
    public void finalize() {
        close();
    }

    public int fetchUsuarioId(Usuario usuario) {
        try {
            Statement st = conexao.createStatement();

            String sql = "SELECT id FROM usuario WHERE nome = '" + usuario.getNome() + "' AND email = '" + usuario.getEmail() 
                       + "' AND cpf = '" + usuario.getCpf() + "' LIMIT 1";

            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                return rs.getInt("id");
            }
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;  
    }

    public boolean insert(Usuario usuario) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "INSERT INTO \"usuario\" (\"nome\", \"email\", \"senha\", \"imagem\", \"data_de_nascimento\", \"telefone\", \"cpf\", \"moradia\") "
                       + "VALUES ('" + usuario.getNome() + "', '" + usuario.getEmail() + "', '" + usuario.getSenha() + "', '" 
                       + usuario.getImagem() + "', '" + usuario.getDataDeNascimento() + "', '" + usuario.getTelefone() + "', '" 
                       + usuario.getCpf() + "', '" + usuario.getMoradia() + "');";
            System.out.println(sql);

            st.executeUpdate(sql);
            st.close();
            status = true;

            System.out.println(usuario.toString());

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean update(Usuario usuario, int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "UPDATE usuario SET nome = '" + usuario.getNome() + "', email = '" + usuario.getEmail() 
                       + "', senha = '" + usuario.getSenha() + "', imagem = '" + usuario.getImagem() 
                       + "', data_de_nascimento = '" + usuario.getDataDeNascimento() + "', telefone = '" + usuario.getTelefone() 
                       + "', cpf = '" + usuario.getCpf() + "', moradia = '" + usuario.getMoradia() 
                       + "' WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean delete(int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "DELETE FROM usuario WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public List<Usuario> list(int id1, int id2) {
        List<Usuario> usuarios = new ArrayList<Usuario>();

        try {
            Statement st = conexao.createStatement();

            String sql = "SELECT * FROM usuario WHERE id BETWEEN " + id1 + " AND " + id2;
            System.out.println(sql);

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setImagem(rs.getString("imagem"));
                usuario.setDataDeNascimento(rs.getString("data_de_nascimento"));
                usuario.setTelefone(rs.getString("telefone"));
                usuario.setCpf(rs.getString("cpf"));
                usuario.setMoradia(rs.getString("moradia"));
                usuarios.add(usuario);
            }

            for (Usuario u : usuarios) {
                System.out.println(u.toString());
            }

            rs.close();
            st.close();

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }

        return usuarios;
    }
}
