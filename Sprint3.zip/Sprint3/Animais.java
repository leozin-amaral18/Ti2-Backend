package sprint3;
import java.time.LocalDate;


public class Animais {

	private int id;
	private String especie;
	private int idade;
	private double peso;
	private String raca;
	private String porte; // Porte do animal (pequeno, médio, grande)
	private LocalDate dataNascimento;
	private LocalDate dataEntrada;
	private LocalDate dataSaida;
	private boolean castrado;
	private String sexo; // Masculino ou Feminino
		
	public Animais() {
		super();
		this.especie = "";
		this.idade = 0;
		this.peso = 0.0;
		this.raca = "";
		this.porte = "";
		this.dataNascimento = null;
		this.dataEntrada = null;
		this.dataSaida = null;
		this.castrado = false;
		this.sexo = "";
	}

	public Animais(String especie, int idade, double peso, String raca, String porte, LocalDate dataNascimento,
			LocalDate dataEntrada, LocalDate dataSaida, boolean castrado, String sexo) {
		super();
		this.especie = especie;
		this.idade = idade;
		this.peso = peso;
		this.raca = raca;
		this.porte = porte;
		this.dataNascimento = dataNascimento;
		this.dataEntrada = dataEntrada;
		this.dataSaida = dataSaida;
		this.castrado = castrado;
		this.sexo = sexo;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	
	public String getPorte() {
		return porte;
	}
	public void setPorte(String porte) {
		this.porte = porte;
	}

	public LocalDate getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public LocalDate getDataEntrada() {
		return dataEntrada;
	}
	public void setDataEntrada(LocalDate dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	public LocalDate getDataSaida() {
		return dataSaida;
	}
	public void setDataSaida(LocalDate dataSaida) {
		this.dataSaida = dataSaida;
	}

	public boolean isCastrado() {
		return castrado;
	}
	public void setCastrado(boolean castrado) {
		this.castrado = castrado;
	}

	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	@Override
	public String toString() {
		return "Animais [especie=" + especie + ", idade=" + idade + ", peso=" + peso + ", raca=" + raca + ", porte=" + porte 
				+ ", dataNascimento=" + dataNascimento + ", dataEntrada=" + dataEntrada + ", dataSaida=" + dataSaida 
				+ ", castrado=" + castrado + ", sexo=" + sexo + "]";
	}
}
