package sprint3;

public class Formulario {
    private int id;
    private int usuarioId;
    private int animalId;
    private String formularioAnimal;
    private String formularioUser;

    public Formulario() {
        this.id = 0;
        this.usuarioId = 0;
        this.animalId = 0;
        this.formularioAnimal = "";
        this.formularioUser = "";
    }

    public Formulario(int id, int usuarioId, int animalId, String formularioAnimal, String formularioUser) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.animalId = animalId;
        this.formularioAnimal = formularioAnimal;
        this.formularioUser = formularioUser;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public int getAnimalId() {
        return animalId;
    }

    public void setAnimalId(int animalId) {
        this.animalId = animalId;
    }

    public String getFormularioAnimal() {
        return formularioAnimal;
    }

    public void setFormularioAnimal(String formularioAnimal) {
        this.formularioAnimal = formularioAnimal;
    }

    public String getFormularioUser() {
        return formularioUser;
    }

    public void setFormularioUser(String formularioUser) {
        this.formularioUser = formularioUser;
    }

    @Override
    public String toString() {
        return "Formulario [id=" + id + ", usuarioId=" + usuarioId + ", animalId=" + animalId + ", formularioAnimal="
                + formularioAnimal + ", formularioUser=" + formularioUser + "]";
    }
}
