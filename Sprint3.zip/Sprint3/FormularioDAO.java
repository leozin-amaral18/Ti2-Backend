package sprint3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormularioDAO extends DAO {

    public FormularioDAO() {
        super();
        conectar();
    }

    @Override
    public void finalize() {
        close();
    }

    public boolean insert(Formulario formulario) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "INSERT INTO \"formulario\" (\"usuarioId\", \"animalId\", \"formularioAnimal\", \"formularioUser\") "
                       + "VALUES (" + formulario.getUsuarioId() + ", " + formulario.getAnimalId() + ", '" 
                       + formulario.getFormularioAnimal() + "', '" + formulario.getFormularioUser() + "');";
            System.out.println(sql);

            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean update(Formulario formulario, int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "UPDATE formulario SET usuarioId = " + formulario.getUsuarioId() + ", animalId = " 
                       + formulario.getAnimalId() + ", formularioAnimal = '" + formulario.getFormularioAnimal() 
                       + "', formularioUser = '" + formulario.getFormularioUser() + "' WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean delete(int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "DELETE FROM formulario WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public List<Formulario> list(int id1, int id2) {
        List<Formulario> formularios = new ArrayList<Formulario>();

        try {
            Statement st = conexao.createStatement();

            String sql = "SELECT * FROM formulario WHERE id BETWEEN " + id1 + " AND " + id2;
            System.out.println(sql);

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Formulario formulario = new Formulario();
                formulario.setId(rs.getInt("id"));
                formulario.setUsuarioId(rs.getInt("usuarioId"));
                formulario.setAnimalId(rs.getInt("animalId"));
                formulario.setFormularioAnimal(rs.getString("formularioAnimal"));
                formulario.setFormularioUser(rs.getString("formularioUser"));
                formularios.add(formulario);
            }

            rs.close();
            st.close();

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }

        return formularios;
    }

}
