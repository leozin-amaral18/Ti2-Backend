package sprint3;

public class Usuario {
    private int id;
    private String nome;
    private String email;
    private String senha;
    private String imagem;
    private String dataDeNascimento;
    private String telefone;
    private String cpf;
    private String moradia; // "casa" ou "apartamento"

    // Construtor padrão
    public Usuario() {
        this.nome = "";
        this.email = "";
        this.senha = "";
        this.imagem = "";
        this.dataDeNascimento = "";
        this.telefone = "";
        this.cpf = "";
        this.moradia = "";
    }

    // Construtor com parâmetros
    public Usuario(int id, String nome, String email, String senha, String imagem, String dataDeNascimento, 
                   String telefone, String cpf, String moradia) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.imagem = imagem;
        this.dataDeNascimento = dataDeNascimento;
        this.telefone = telefone;
        this.cpf = cpf;
        this.moradia = moradia;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getMoradia() {
        return moradia;
    }

    public void setMoradia(String moradia) {
        this.moradia = moradia;
    }

    @Override
    public String toString() {
        return "Usuario [id=" + id + ", nome=" + nome + ", email=" + email + ", senha=" + senha + ", imagem=" + imagem +
               ", dataDeNascimento=" + dataDeNascimento + ", telefone=" + telefone + ", cpf=" + cpf + ", moradia=" + moradia + "]";
    }
}
