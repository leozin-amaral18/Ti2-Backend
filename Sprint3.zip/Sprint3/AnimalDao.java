package sprint3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAO extends DAO {

    public AnimalDAO() {
        super();
        conectar();
    }

    @Override
    public void finalize() {
        close();
    }

    public boolean insert(Animal animal) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "INSERT INTO \"animal\" (\"especie\", \"idade\", \"peso\", \"raca\", \"porte\", \"dataNascimento\", \"dataEntrada\", \"dataSaida\", \"castrado\", \"sexo\") "
                       + "VALUES ('" + animal.getEspecie() + "', " + animal.getIdade() + ", " + animal.getPeso() 
                       + ", '" + animal.getRaca() + "', '" + animal.getPorte() + "', '" 
                       + animal.getDataNascimento() + "', '" + animal.getDataEntrada() + "', '" 
                       + animal.getDataSaida() + "', " + animal.isCastrado() + ", '" + animal.getSexo() + "');";
            System.out.println(sql);

            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean update(Animal animal, int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "UPDATE animal SET especie = '" + animal.getEspecie() + "', idade = " + animal.getIdade() 
                       + ", peso = " + animal.getPeso() + ", raca = '" + animal.getRaca() + "', porte = '" 
                       + animal.getPorte() + "', dataNascimento = '" + animal.getDataNascimento() + "', dataEntrada = '" 
                       + animal.getDataEntrada() + "', dataSaida = '" + animal.getDataSaida() + "', castrado = " 
                       + animal.isCastrado() + ", sexo = '" + animal.getSexo() + "' WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean delete(int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "DELETE FROM animal WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public List<Animal> list(int id1, int id2) {
        List<Animal> animais = new ArrayList<Animal>();

        try {
            Statement st = conexao.createStatement();

            String sql = "SELECT * FROM animal WHERE id BETWEEN " + id1 + " AND " + id2;
            System.out.println(sql);

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Animal animal = new Animal();
                animal.setId(rs.getInt("id"));
                animal.setEspecie(rs.getString("especie"));
                animal.setIdade(rs.getInt("idade"));
                animal.setPeso(rs.getDouble("peso"));
                animal.setRaca(rs.getString("raca"));
                animal.setPorte(rs.getString("porte"));
                animal.setDataNascimento(rs.getDate("dataNascimento").toString());
                animal.setDataEntrada(rs.getDate("dataEntrada").toString());
                animal.setDataSaida(rs.getDate("dataSaida").toString());
                animal.setCastrado(rs.getBoolean("castrado"));
                animal.setSexo(rs.getString("sexo"));
                animais.add(animal);
            }

            rs.close();
            st.close();

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }

        return animais;
    }

}
