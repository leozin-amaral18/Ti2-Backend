package sprint3;

public class Comentario {
    private int id;
    private int usuarioId;
    private int animalId;
    private String conteudo;
    private String comentarioUser;
    private String comentarioAnimal;

    public Comentario() {
        this.id = 0;
        this.usuarioId = 0;
        this.animalId = 0;
        this.conteudo = "";
        this.comentarioUser = "";
        this.comentarioAnimal = "";
    }

    public Comentario(int id, int usuarioId, int animalId, String conteudo, String comentarioUser, String comentarioAnimal) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.animalId = animalId;
        this.conteudo = conteudo;
        this.comentarioUser = comentarioUser;
        this.comentarioAnimal = comentarioAnimal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public int getAnimalId() {
        return animalId;
    }

    public void setAnimalId(int animalId) {
        this.animalId = animalId;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getComentarioUser() {
        return comentarioUser;
    }

    public void setComentarioUser(String comentarioUser) {
        this.comentarioUser = comentarioUser;
    }

    public String getComentarioAnimal() {
        return comentarioAnimal;
    }

    public void setComentarioAnimal(String comentarioAnimal) {
        this.comentarioAnimal = comentarioAnimal;
    }

    @Override
    public String toString() {
        return "Comentario [id=" + id + ", usuarioId=" + usuarioId + ", animalId=" + animalId + ", conteudo=" + conteudo
                + ", comentarioUser=" + comentarioUser + ", comentarioAnimal=" + comentarioAnimal + "]";
    }
}
