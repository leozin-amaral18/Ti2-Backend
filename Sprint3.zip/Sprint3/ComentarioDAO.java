package sprint3;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComentarioDAO extends DAO {

    public ComentarioDAO() {
        super();
        conectar();
    }

    @Override
    public void finalize() {
        close();
    }

    public boolean insert(Comentario comentario) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "INSERT INTO \"comentario\" (\"usuarioId\", \"animalId\", \"conteudo\", \"comentarioUser\", \"comentarioAnimal\") "
                       + "VALUES (" + comentario.getUsuarioId() + ", " + comentario.getAnimalId() + ", '" 
                       + comentario.getConteudo() + "', '" + comentario.getComentarioUser() + "', '" 
                       + comentario.getComentarioAnimal() + "');";
            System.out.println(sql);

            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean update(Comentario comentario, int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "UPDATE comentario SET usuarioId = " + comentario.getUsuarioId() + ", animalId = " 
                       + comentario.getAnimalId() + ", conteudo = '" + comentario.getConteudo() + "', comentarioUser = '" 
                       + comentario.getComentarioUser() + "', comentarioAnimal = '" + comentario.getComentarioAnimal() 
                       + "' WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean delete(int id) {
        boolean status = false;
        try {
            Statement st = conexao.createStatement();
            String sql = "DELETE FROM comentario WHERE id = " + id;
            System.out.println(sql);
            st.executeUpdate(sql);
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public List<Comentario> list(int id1, int id2) {
        List<Comentario> comentarios = new ArrayList<Comentario>();

        try {
            Statement st = conexao.createStatement();

            String sql = "SELECT * FROM comentario WHERE id BETWEEN " + id1 + " AND " + id2;
            System.out.println(sql);

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Comentario comentario = new Comentario();
                comentario.setId(rs.getInt("id"));
                comentario.setUsuarioId(rs.getInt("usuarioId"));
                comentario.setAnimalId(rs.getInt("animalId"));
                comentario.setConteudo(rs.getString("conteudo"));
                comentario.setComentarioUser(rs.getString("comentarioUser"));
                comentario.setComentarioAnimal(rs.getString("comentarioAnimal"));
                comentarios.add(comentario);
            }

            rs.close();
            st.close();

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }

        return comentarios;
    }

}
