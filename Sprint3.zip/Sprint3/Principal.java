package sprint3;

import static spark.Spark.*;

import java.util.List;

public class Principal {
    public static void main(String[] args) {	
    	
    	staticFiles.location("/public");    	
    	        	
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        
        post("/inserir_usuario", (req, res) -> {
            Usuario usuario = new Usuario();
            String nome = req.queryParams("nome");
            String email = req.queryParams("email");
            String senha = req.queryParams("senha");
            String imagem = req.queryParams("imagem");
            String dataDeNascimento = req.queryParams("dataDeNascimento");
            String telefone = req.queryParams("telefone");
            String cpf = req.queryParams("cpf");
            String moradia = req.queryParams("moradia"); // casa ou apartamento
            
            usuario.setNome(nome);
            usuario.setEmail(email);
            usuario.setSenha(senha);
            usuario.setImagem(imagem);
            usuario.setDataDeNascimento(dataDeNascimento);
            usuario.setTelefone(telefone);
            usuario.setCpf(cpf);
            usuario.setMoradia(moradia);
            
            usuarioDAO.insert(usuario);
            
            return null;
        });
        
        post("/atualizar_usuario", (req, res) -> {
            Usuario usuario = new Usuario();
            int id = Integer.parseInt(req.queryParams("id"));
            String nome = req.queryParams("nome");
            String email = req.queryParams("email");
            String senha = req.queryParams("senha");
            String imagem = req.queryParams("imagem");
            String dataDeNascimento = req.queryParams("dataDeNascimento");
            String telefone = req.queryParams("telefone");
            String cpf = req.queryParams("cpf");
            String moradia = req.queryParams("moradia"); // casa ou apartamento
            
            usuario.setNome(nome);
            usuario.setEmail(email);
            usuario.setSenha(senha);
            usuario.setImagem(imagem);
            usuario.setDataDeNascimento(dataDeNascimento);
            usuario.setTelefone(telefone);
            usuario.setCpf(cpf);
            usuario.setMoradia(moradia);
            
            usuarioDAO.update(usuario, id);
            
            return null;
        });
        
        post("/remover_usuario", (req, res) -> {
            int id = Integer.parseInt(req.queryParams("id"));
            
            usuarioDAO.delete(id);
            
            return null;
        });
        
        get("/listar_usuarios", (req, res) -> {
            List<Usuario> usuarios = usuarioDAO.list(Integer.parseInt(req.queryParams("id1")), Integer.parseInt(req.queryParams("id2")));
            
            StringBuilder html = new StringBuilder();
            html.append("<html>");
            html.append("<head><title>Lista de Usuários</title></head>");
            html.append("<body>");
            html.append("<h1>Usuários:</h1>");
            html.append("<ul>");
            
            for (Usuario usuario : usuarios) {
                html.append("<li>Nome: ").append(usuario.getNome())
                    .append(", Email: ").append(usuario.getEmail())
                    .append(", Senha: ").append(usuario.getSenha())
                    .append(", Imagem: ").append(usuario.getImagem())
                    .append(", Data de Nascimento: ").append(usuario.getDataDeNascimento())
                    .append(", Telefone: ").append(usuario.getTelefone())
                    .append(", CPF: ").append(usuario.getCpf())
                    .append(", Moradia: ").append(usuario.getMoradia()).append("</li>");
            }
            
            html.append("</ul>");
            html.append("</body>");
            html.append("</html>");
            
            return html.toString();
        });
    }
}
